Traceback (most recent call last):
  File "<string>", line 5, in <module>
    sql = data[0]['string_agg']
          ~~~~~~~^^^^^^^^^^^^^^
TypeError: string indices must be integers, not 'str'
