-- ============================================
-- COMPLETE DATABASE BACKUP
-- Ruiz Automotores KPI Dashboard
-- Generated: 2026-10-01
-- Supabase project: pxlbvlxwmlvqdczyduvh
-- ============================================
--
-- 16 tables, 651 total rows
--
-- areas: 7 | kpis: 61 | kpi_data: 61 | kpi_breakdowns: 245
-- custom_fields: 64 | formulas: 23 | data_entries: 27
-- field_values: 140 | profiles: 7 | user_areas: 5
-- api_connections: 3 | firecrawl_connections: 1
-- data_source_config: 1 | asofix_metrics: 6
-- notifications: 5 | griba_leads: 0
--
-- ============================================
-- PART 1: SCHEMA (from migrations)
-- ============================================
/*
# Create KPI Dashboard Schema for Ruiz Automotores

## Overview
Creates a comprehensive management indicators dashboard with 7 business areas and their KPIs.
Single-tenant (no auth) — all data is shared/public.

## New Tables
1. `areas` — Business areas (Ventas 0km, Plan Rombo, Mi Auto Ya!, Postventa, Calidad, RRHH, Adm. y Finanzas)
2. `kpis` — KPI definitions per area with formulas, definitions, decisions they enable
3. `kpi_data` — Actual KPI values with current value, target, previous value, trend, and monthly series
4. `kpi_breakdowns` — Detailed breakdown rows for each KPI (e.g. by vendedor, modelo, canal)

## Security
- RLS enabled on all tables
- Anon + authenticated CRUD (single-tenant, no auth)
*/

-- Business areas
CREATE TABLE IF NOT EXISTS areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  icon text NOT NULL,
  description text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- KPI definitions
CREATE TABLE IF NOT EXISTS kpis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  area_id uuid NOT NULL REFERENCES areas(id) ON DELETE CASCADE,
  name text NOT NULL,
  definition text NOT NULL,
  formula text NOT NULL,
  decision text NOT NULL,
  unit text NOT NULL DEFAULT '%',
  target_direction text NOT NULL DEFAULT 'up',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- KPI actual data (current snapshot + monthly series stored as JSONB)
CREATE TABLE IF NOT EXISTS kpi_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id uuid NOT NULL REFERENCES kpis(id) ON DELETE CASCADE,
  current_value numeric NOT NULL DEFAULT 0,
  target_value numeric NOT NULL DEFAULT 0,
  previous_value numeric NOT NULL DEFAULT 0,
  trend text NOT NULL DEFAULT 'stable',
  series jsonb NOT NULL DEFAULT '[]'::jsonb,
  updated_at timestamptz DEFAULT now()
);

-- KPI breakdown rows (for detailed sub-data per KPI)
CREATE TABLE IF NOT EXISTS kpi_breakdowns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id uuid NOT NULL REFERENCES kpis(id) ON DELETE CASCADE,
  label text NOT NULL,
  value numeric NOT NULL DEFAULT 0,
  target numeric,
  extra jsonb DEFAULT '{}'::jsonb,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE areas ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpis ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpi_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpi_breakdowns ENABLE ROW LEVEL SECURITY;

-- Policies: single-tenant, anon + authenticated full access
DROP POLICY IF EXISTS "anon_crud_areas" ON areas;
CREATE POLICY "anon_crud_areas" ON areas FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_kpis" ON kpis;
CREATE POLICY "anon_crud_kpis" ON kpis FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_kpi_data" ON kpi_data;
CREATE POLICY "anon_crud_kpi_data" ON kpi_data FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_crud_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "anon_crud_kpi_breakdowns" ON kpi_data FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "anon_select_kpi_breakdowns" ON kpi_breakdowns FOR SELECT TO anon, authenticated USING (true);

-- Insert policy for areas
DROP POLICY IF EXISTS "anon_insert_areas" ON areas;
CREATE POLICY "anon_insert_areas" ON areas FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_insert_kpis" ON kpis;
CREATE POLICY "anon_insert_kpis" ON kpis FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_insert_kpi_data" ON kpi_data;
CREATE POLICY "anon_insert_kpi_data" ON kpi_data FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_insert_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "anon_insert_kpi_breakdowns" ON kpi_breakdowns FOR INSERT TO anon, authenticated WITH CHECK (true);

-- Update policies
DROP POLICY IF EXISTS "anon_update_areas" ON areas;
CREATE POLICY "anon_update_areas" ON areas FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_kpis" ON kpis;
CREATE POLICY "anon_update_kpis" ON kpis FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_kpi_data" ON kpi_data;
CREATE POLICY "anon_update_kpi_data" ON kpi_data FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "anon_update_kpi_breakdowns" ON kpi_breakdowns FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- Delete policies
DROP POLICY IF EXISTS "anon_delete_areas" ON areas;
CREATE POLICY "anon_delete_areas" ON areas FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_delete_kpis" ON kpis;
CREATE POLICY "anon_delete_kpis" ON kpis FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_delete_kpi_data" ON kpi_data;
CREATE POLICY "anon_delete_kpi_data" ON kpi_data FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_delete_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "anon_delete_kpi_breakdowns" ON kpi_breakdowns FOR DELETE TO anon, authenticated USING (true);/*
# Seed KPI Dashboard Data

Inserts all 7 business areas, their KPIs with definitions/formulas/decisions,
sample current values with targets, monthly series, and breakdowns.
*/

-- ============================================================
-- AREAS
-- ============================================================
INSERT INTO areas (slug, name, icon, description, sort_order) VALUES
('ventas-0km', 'Ventas 0 km', 'Car', 'Vehículos nuevos: cumplimiento, conversión, margen y productividad comercial.', 1),
('plan-rombo', 'Plan Rombo', 'TrendingUp', 'Suscripciones, cartera, adjudicaciones y aporte económico del plan de ahorro.', 2),
('mi-auto-ya', 'Mi Auto Ya!', 'RefreshCw', 'Usados: compra, peritaje, preparación, rotación de stock y venta.', 3),
('postventa', 'Postventa', 'Wrench', 'Taller, repuestos, stock, agenda y cumplimiento de compras a Renault.', 4),
('calidad', 'Calidad', 'ShieldCheck', 'Mystery Shopping, NPS, DDA, OCV, Hot Alert e incentivos de calidad.', 5),
('rrhh', 'Recursos Humanos', 'Users', 'Ausentismo, rotación, costo de personal y gestión disciplinaria.', 6),
('admn-finanzas', 'Administración y Finanzas', 'Landmark', 'Liquidez, endeudamiento, rentabilidad, costos y créditos a cobrar.', 7)
ON CONFLICT (slug) DO NOTHING;

-- Helper: get area IDs
DO $$ DECLARE
  v_ventas uuid; v_rombo uuid; v_miauto uuid; v_postv uuid; v_calidad uuid; v_rrhh uuid; v_finan uuid;
BEGIN
  SELECT id INTO v_ventas FROM areas WHERE slug = 'ventas-0km';
  SELECT id INTO v_rombo FROM areas WHERE slug = 'plan-rombo';
  SELECT id INTO v_miauto FROM areas WHERE slug = 'mi-auto-ya';
  SELECT id INTO v_postv FROM areas WHERE slug = 'postventa';
  SELECT id INTO v_calidad FROM areas WHERE slug = 'calidad';
  SELECT id INTO v_rrhh FROM areas WHERE slug = 'rrhh';
  SELECT id INTO v_finan FROM areas WHERE slug = 'admn-finanzas';

  -- VENTAS 0 KM
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_ventas, 'Cumplimiento del objetivo comercial y ritmo diario', 'Mide el avance hacia los patentamientos requeridos por fábrica. Distingue boletos, facturación, documentación en gestión, unidades en manos del gestor, patentamientos y entregas.', 'Patentamientos reconocidos ÷ objetivo vigente × 100. Ritmo pendiente = unidades faltantes ÷ días hábiles restantes.', 'Acelerar ventas y trámites que condicionan el cierre; anticipar la escala de Prima Volumen.', '%', 'up', 1),
  (v_ventas, 'Conversión de leads y efectividad por canal y punto de venta', 'Integra el embudo desde el ingreso/asignación del lead hasta la venta; muestra etapas abiertas y motivos de pérdida.', 'Ventas de una cohorte ÷ leads de esa cohorte × 100, por origen, punto y vendedor.', 'Mejorar seguimiento, distribución de oportunidades e inversión comercial sin ocultar leads fallidos.', '%', 'up', 2),
  (v_ventas, 'Margen de contribución por unidad y total', 'Mide el aporte económico de la operación después de descuentos y costos variables; conserva el desglose de bonificación de fábrica y concesionaria.', 'Venta neta + reintegros no incluidos − costo de reposición − costos variables directos.', 'Definir descuentos, modelos prioritarios y operaciones que necesitan autorización por margen.', '$', 'up', 3),
  (v_ventas, 'Productividad comercial por vendedor', 'Muestra cuánto vende cada vendedor, con qué conversión, contribución y seguimiento de oportunidades.', 'Unidades por vendedor y cumplimiento de su objetivo; contribución generada y conversión de su cohorte de leads como desgloses.', 'Asignar objetivos y oportunidades, identificar necesidades de capacitación y evaluar resultados comparables.', 'u.', 'up', 4),
  (v_ventas, 'Productividad comercial por modelo', 'Completa la apertura por modelo y versión para identificar qué productos sostienen volumen y contribución.', 'Unidades por modelo ÷ objetivo asignado al modelo × 100; participación en ventas y contribución total/media por modelo.', 'Ajustar oferta, campañas y asignación de stock; no confundir un modelo de alto volumen con uno rentable.', '%', 'up', 5),
  (v_ventas, 'Composición de la venta', 'Identifica la participación de contado, toma de usado y crédito, incluyendo operaciones con modalidades combinadas.', 'Operaciones por modalidad ÷ operaciones totales × 100. Categorías exclusivas: contado, permuta, crédito y combinaciones.', 'Evaluar dependencia del crédito, ingreso de usados y necesidades de fondos de cada modalidad.', '%', 'up', 6),
  (v_ventas, 'Autos peritados vs. tomados por vendedor', 'Mide la conversión de usados ofrecidos en parte de pago en unidades efectivamente tomadas, vinculadas al vendedor de 0 km.', 'Vehículos tomados ÷ vehículos peritados de la misma cohorte × 100, por vendedor.', 'Detectar operaciones perdidas por tasación y coordinar condiciones de toma con Mi Auto Ya! sin duplicar vehículos.', '%', 'up', 7),
  (v_ventas, 'Brecha de posicionamiento de precios', 'Compara precios propios con referencias equivalentes por modelo, versión, equipamiento y condición de pago.', '(Precio de cierre propio − precio de referencia) ÷ precio de referencia × 100.', 'Revisar bonificaciones y fundamentar decisiones de precio sin separar competitividad de contribución.', '%', 'down', 8),
  (v_ventas, 'Cumplimiento y tiempo de entrega', 'Mide el plazo desde boleto hasta entrega y el cumplimiento de la fecha prometida; identifica demoras de documentación y preparación.', 'Entregas en fecha ÷ entregas totales × 100; días promedio por etapa y operaciones abiertas vencidas.', 'Coordinar Secretaría Comercial, gestoría y preparación antes de incumplir la promesa al cliente.', '%', 'up', 9),
  (v_ventas, 'Participación de mercado en Tucumán', 'Sitúa el desempeño de Renault y de Ruiz Automotores frente al mercado provincial y su evolución.', 'Patentamientos de la marca o del concesionario ÷ patentamientos del mercado comparable × 100.', 'Distinguir contracción del mercado de pérdida propia de participación y contextualizar el objetivo de fábrica.', '%', 'up', 10);

  -- PLAN ROMBO
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_rombo, 'Cumplimiento del objetivo de suscripciones', 'Mide las suscripciones aceptadas frente al objetivo mensual comunicado por Plan Rombo y la escala de incentivo que corresponda.', 'Suscripciones aceptadas ÷ objetivo mensual × 100; avance diario y apertura por vendedor y punto de venta.', 'Corregir el ritmo comercial y anticipar el efecto de alcanzar o perder un escalón de incentivo.', '%', 'up', 1),
  (v_rombo, 'Contribución económica mensual', 'Integra ingresos por suscripción, mantenimiento de cartera, débito y entrega, menos comisiones y costos directos.', 'Ingresos atribuibles − comisiones − costos directos. Resultado devengado y flujo percibido por separado.', 'Evaluar el aporte de la unidad y explicar la diferencia entre producción, incentivos generados y cobros.', '$', 'up', 2),
  (v_rombo, 'Cartera activa y tasa de caída por cohorte', 'Muestra la permanencia de contratos del mismo período de origen a medida que avanzan las cuotas.', 'Contratos activos en cuota n ÷ contratos iniciales de la cohorte × 100; caída = 100% − tasa activa.', 'Identificar campañas o vendedores con mayor caída y proteger los ingresos futuros de cartera.', '%', 'up', 3),
  (v_rombo, 'Cobertura de contacto del call center', 'Distingue intentos de contacto de conversaciones efectivas con clientes convocados a licitar.', 'Clientes con intento registrado ÷ asignados × 100; clientes contactados efectivamente ÷ asignados × 100.', 'Distribuir carga y mejorar cobertura y calidad de contacto dentro de la ventana de cada acto.', '%', 'up', 4),
  (v_rombo, 'Conversión de invitaciones, ofertas y adjudicaciones', 'Expone el embudo de convocados, contactados, ofertas, adjudicaciones y entregas, con cantidades en cada etapa.', 'Ofertas ÷ contactos efectivos; adjudicaciones ÷ ofertas; entregas ÷ adjudicaciones × 100.', 'Evaluar guiones y seguimiento, identificar el punto de pérdida y aumentar la efectividad de las licitaciones.', '%', 'up', 5),
  (v_rombo, 'Productividad comisional por vendedor y punto de venta', 'Relaciona producción, comisiones generadas y aporte al negocio.', 'Suscripciones por vendedor ÷ objetivo × 100; comisiones generadas y comparación con su remuneración básica.', 'Revisar producción, concentración y esquema comisional; evitar evaluar sólo cantidad de contratos.', '%', 'up', 6),
  (v_rombo, 'Conversión y rentabilidad de leads', 'Completa la conversión y el retorno de las oportunidades obtenidas con inversión identificable.', 'Suscripciones de la cohorte ÷ leads atribuibles × 100. Retorno = (contribución atribuible antes de captación − inversión) ÷ inversión × 100.', 'Reasignar inversión entre canales considerando costos y permanencia de los contratos, no sólo ingresos brutos.', '%', 'up', 7),
  (v_rombo, 'Resolución administrativa y escalamiento', 'Mide cierre de trámites, demora, casos pendientes y escalamiento al nivel gerencial.', 'Casos vencibles en el período cerrados dentro del plazo ÷ casos vencibles × 100; días por caso y escalaciones no justificadas ÷ escalaciones totales.', 'Resolver en el nivel adecuado, reducir burocracia y reservar a la Gerencia para los casos críticos.', '%', 'up', 8),
  (v_rombo, 'Ciclo de adjudicación y entrega', 'Descompone la demora total en documentación interna, firma, facturación de terminal, arribo, patentamiento y entrega.', 'Fecha de fin − fecha de inicio de cada etapa. Mostrar por separado tiempos internos, de terminal y de otros terceros.', 'Actuar sobre tramos controlables y respaldar reclamos sin atribuir al equipo toda demora externa.', 'días', 'down', 9);

  -- MI AUTO YA!
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_miauto, 'Cumplimiento del objetivo de unidades', 'Mide las unidades entregadas y cobradas frente al objetivo interno aprobado para Mi Auto Ya!, sin trasladar una meta de fábrica.', 'Unidades entregadas y cobradas ÷ objetivo interno mensual × 100. Desglosar boletos, entregas y cobranzas pendientes.', 'Ajustar ritmo comercial y capacidad de cierre; identificar la etapa que frena el cumplimiento.', '%', 'up', 1),
  (v_miauto, 'Contribución económica total y por unidad', 'Mide el aporte de la venta después de adquisición o consignación, reacondicionamiento y costos variables.', 'Venta neta − costo de adquisición/consignación − reacondicionamiento − comisiones − otros costos variables atribuibles.', 'Definir condiciones de toma, precios y prioridades de salida; explicar el aporte de cada vehículo.', '$', 'up', 2),
  (v_miauto, 'Composición de la venta', 'Distingue contado, permuta de usado, crédito y operaciones que combinan modalidades.', 'Operaciones por modalidad ÷ operaciones totales × 100.', 'Evaluar generación de caja, necesidad de financiación e ingreso de nuevas unidades por permuta.', '%', 'up', 3),
  (v_miauto, 'Conversión de leads', 'Muestra oportunidades ingresadas, gestionadas, perdidas y cerradas, por origen y vendedor.', 'Ventas cerradas ÷ leads de la misma cohorte × 100. Identificar no contactados, inválidos, duplicados y motivos de pérdida.', 'Mejorar seguimiento y distribución de consultas; evaluar los canales de captación con datos comparables.', '%', 'up', 4),
  (v_miauto, 'Autos peritados vs. tomados por peritador', 'Mide la efectividad de las evaluaciones realizadas por cada peritador para incorporar vehículos al negocio.', 'Vehículos tomados ÷ vehículos peritados de la misma cohorte × 100, por peritador.', 'Revisar criterios de tasación y aceptación; contrastar efectividad con margen y desvío posterior de reparación.', '%', 'up', 5),
  (v_miauto, 'Antigüedad y rotación del stock', 'Mide permanencia de unidades abiertas y velocidad de salida de las vendidas, desde recepción/peritaje y alta.', 'Días en stock por vehículo; promedio de días hasta venta y entrega; participación del stock con más de 60/90 días.', 'Acelerar publicación, preparación o salida y evitar unidades que consumen recursos sin rotar.', 'días', 'down', 6),
  (v_miauto, 'Productividad por vendedor', 'Relaciona unidades, participación en ventas, contribución y comisiones generadas por vendedor.', 'Unidades y contribución por vendedor; participación sobre total; conversión y comisión generada frente a su básico.', 'Capacitar y evaluar desempeño; registrar por separado operaciones frustradas y sus causas.', 'u.', 'up', 7),
  (v_miauto, 'Tiempo desde recepción/peritaje hasta publicación', 'Mide la demora hasta que la unidad está revisada, documentada, fotografiada y disponible para ofrecer.', 'Fecha/hora de publicación o disponibilidad − fecha/hora de recepción.', 'Evitar vehículos fuera de la oferta comercial por falta de preparación, documentación o carga.', 'días', 'down', 8),
  (v_miauto, 'Tiempo de preparación y entrega en fecha', 'Mide los circuitos paralelos de servicio y gestoría desde el boleto hasta la entrega.', 'Días desde boleto hasta vehículo listo; entregas en fecha comprometida ÷ entregas totales × 100.', 'Coordinar mecánica, carrocería, repuestos y documentación; cumplir la promesa de entrega.', '%', 'up', 9);

  -- POSTVENTA
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_postv, 'Entradas al taller por día', 'Mide el volumen de vehículos que ingresan físicamente al taller, separado por sede y tipo de trabajo.', 'Conteo de ingresos diarios vinculados a órdenes de reparación; acumulado mensual y promedio por día operativo.', 'Detectar caída de actividad, ajustar agenda y campañas y dimensionar capacidad disponible.', 'u/día', 'up', 1),
  (v_postv, 'Productividad y utilización de la capacidad del taller', 'Relaciona horas vendidas, presencia disponible y trabajo efectivo.', 'Productividad = horas facturadas ÷ disponibles × 100; utilización = horas trabajadas ÷ disponibles × 100.', 'Identificar si la pérdida está en demanda, tiempos muertos o rendimiento; analizar especialistas por separado.', '%', 'up', 2),
  (v_postv, 'Ciclo de vida de órdenes de trabajo', 'Mide duración y envejecimiento de las órdenes, por asesor, etapa y tipo de intervención.', 'Fecha/hora de cierre − apertura; promedio/mediana y cantidad de órdenes abiertas fuera del plazo acordado.', 'Resolver demoras, ordenar la carga de asesores y anticipar vehículos detenidos y reclamos.', 'días', 'down', 3),
  (v_postv, 'Reparación correcta a la primera', 'Control interno de retornos, retrabajos y garantías internas atribuibles a la misma causa.', 'Órdenes con retrabajo atribuible ÷ órdenes cerradas de la base definida × 100.', 'Corregir causas técnicas y control final, sin premiar productividad a costa de calidad.', '%', 'down', 4),
  (v_postv, 'Efectividad de la agenda', 'Muestra la ocupación programada y la asistencia real de los turnos, diferenciadas de la utilización del mecánico.', 'Horas agendadas ÷ capacidad disponible × 100; inasistencias ÷ turnos agendados × 100.', 'Ajustar confirmaciones y captación; evitar una agenda llena que no se transforme en entradas reales.', '%', 'up', 5),
  (v_postv, 'Ventas y margen por familia, mano de obra y canal', 'Mide repuestos y servicios por familia y por mostrador, taller interno y e-commerce/Mercado Libre.', 'Ventas netas − costo de reposición/directo; margen ÷ ventas netas × 100.', 'Orientar compras y acciones comerciales; distinguir canales de alto volumen de los que aportan margen.', '$', 'up', 6),
  (v_postv, 'Stock Vivo, Durmiente y Muerto; rotación', 'Expone valor y participación de cada categoría, sin convertir automáticamente stock antiguo en pérdida contable.', 'Valor por categoría ÷ inventario total × 100; rotación = costo vendido del período ÷ inventario promedio.', 'Sincerar existencia, definir salida o recuperación y evitar reposición de piezas sin demanda.', '%', 'up', 7),
  (v_postv, 'Cumplimiento de compras de repuestos a Renault', 'Mide el objetivo mensual y su regularidad con pedidos a valor PNC en estados admitidos por Renault.', 'Pedidos facturados, asignados o de entrega directa ÷ objetivo PNC × 100. Excluir herramientas, equipos, publicidad y mobiliario.', 'Anticipar incumplimientos e incentivos; planificar compras sin aumentar stock inmovilizado innecesario.', '%', 'up', 8),
  (v_postv, 'Exactitud y trazabilidad de inventario', 'Compara existencia física y sistema, y el respaldo oportuno de cada movimiento.', 'Ítems coincidentes ÷ ítems auditados × 100; movimientos documentados ÷ movimientos revisados × 100.', 'Prevenir faltantes y demoras por stock incorrecto; dar respaldo al sinceramiento del inventario.', '%', 'up', 9),
  (v_postv, 'Nivel de servicio de abastecimiento y e-commerce', 'Mide disponibilidad, precisión y velocidad para abastecer taller y preparar pedidos digitales.', 'Solicitudes completas y a tiempo ÷ solicitudes totales × 100; errores y tiempo de preparación como desgloses.', 'Evitar técnicos detenidos y devoluciones; acompañar la venta digital con despacho confiable.', '%', 'up', 10);

  -- CALIDAD
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_calidad, 'Mystery Shopping', 'Mide el resultado de cliente incógnito con dos aperturas independientes: Ventas y Postventa.', 'Promedio Lead y Call.', 'Proteger las llaves de cobro y corregir el canal o punto que reduce el resultado.', '%', 'up', 1),
  (v_calidad, 'Índice VoC NPS: VN y PV', 'Evalúa satisfacción mediante la ponderación de tres preguntas. Promotores: 5 estrellas; neutros: 4; detractores: 1, 2 y 3.', 'NPS por pregunta = (promotores − detractores) ÷ encuestas × 100. Index = 50% general + 25% segunda + 25% tercera. Objetivo: ≥85.', 'Priorizar causas de insatisfacción que afectan resultados e incentivos, sin usar sólo el porcentaje de cinco estrellas.', '%', 'up', 2),
  (v_calidad, 'DDA: Recepción y Preparación', 'Mide uso de DDA con dos bases distintas de vehículos; cada proceso pesa 10% en la Prima Calidad Comercial.', 'Recepción = VIN con recepción DDA ÷ VIN asignados con fecha ARA × 100. Preparación = VIN con preparación DDA ÷ VIN con entrega administrativa global × 100. Objetivo: ≥85%.', 'Asegurar registros que habilitan incentivos de proceso, sujetos a Hot Alert; no promediar etapas indiscriminadamente.', '%', 'up', 3),
  (v_calidad, 'OCV Battery Check', 'Control de batería con útil CLIP en preparación previa a entrega.', 'VIN con OCV válido ÷ VIN de la base oficial evaluada × 100. Objetivo ≥85%.', 'Detectar VIN sin control válido y preservar el incentivo OCV, condicionado por Hot Alert.', '%', 'up', 4),
  (v_calidad, 'Hot Alert: gestión y cierre', 'Alertas por satisfacción general de 3 estrellas o menos.', 'Días desde generación hasta cierre; alertas abiertas, vencidas y cerradas por plazo.', 'Priorizar casos que pueden bloquear DDA y OCV; no asumir que un promedio de tiempos habilita la llave.', 'días', 'down', 5),
  (v_calidad, 'Incentivos de Calidad: habilitados, cobrados y en riesgo', 'Traduce el desempeño a dinero, separado entre Prima Calidad Comercial y animación Calidad de Postventa.', 'Estimación = Σ(base elegible validada × tasa publicada por componente). Exponer estimado, informado, facturado, cobrado, retenido y en riesgo.', 'Priorizar la brecha de mayor impacto económico y controlar reconsideraciones y recuperos sin anticipar cobros.', '$', 'up', 6);

  -- RRHH
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_rrhh, 'Tasa de ausentismo', 'Mide la capacidad laboral perdida por ausencias justificadas e injustificadas y permite identificar recurrencia por área.', 'Horas o días de ausencia ÷ horas o días laborables planificados × 100.', 'Planificar dotación, cubrir puestos críticos y actuar sobre ausentismo recurrente.', '%', 'down', 1),
  (v_rrhh, 'Tasa de llegadas tarde y reincidencia', 'Mide ingresos posteriores al horario y la proporción de empleados con tardanzas repetidas.', 'Llegadas tarde ÷ ingresos esperados × 100; empleados con ≥3 tardanzas ÷ dotación × 100.', 'Intervenir antes del cierre de liquidación, aplicar criterios uniformes y prevenir contaminación del clima.', '%', 'down', 2),
  (v_rrhh, 'Incidencia y días perdidos por ART/licencias', 'Mide frecuencia y severidad de accidentes, ART y licencias médicas, sin exponer información clínica individual.', 'Casos por cada 100 empleados; y días perdidos ÷ dotación promedio.', 'Revisar prevención, ergonomía, cobertura de puestos y concentración de riesgos por área.', 'casos', 'down', 3),
  (v_rrhh, 'Reincidencia disciplinaria y oportunidad de actuación', 'Mide repetición de una conducta luego de apercibimiento o suspensión y cuánto tarda el circuito formal en actuar.', 'Personas con reincidencia en 90 días ÷ personas con medida previa; días entre hecho y resolución.', 'Evaluar efectividad de las medidas y evitar respuestas tardías o inconsistentes.', '%', 'down', 4),
  (v_rrhh, 'Rotación de personal', 'Mide altas y bajas respecto de la dotación promedio, diferenciando salida voluntaria, involuntaria, área y motivo.', 'Bajas del período ÷ dotación promedio × 100.', 'Detectar sectores inestables, evaluar calidad de incorporación y anticipar costos de reemplazo.', '%', 'down', 5),
  (v_rrhh, 'Costo total de personal y costo por área', 'Mide remuneraciones, cargas y beneficios por área y por empleado equivalente a tiempo completo.', 'Sueldos + cargas sociales + beneficios + variables.', 'Presupuestar, comparar estructura con actividad y evaluar capacidad ociosa sin mirar sólo cantidad de personas.', '$', 'up', 6),
  (v_rrhh, 'Costo potencial de desvinculación', 'Estima el pasivo potencial de indemnización para escenarios de decisión, actualizado por antigüedad y conceptos aplicables.', 'Suma de estimaciones individuales vigentes según la metodología aprobada por RRHH y asesores legales.', 'Evaluar escenarios organizativos y necesidades de liquidez antes de tomar decisiones.', '$', 'down', 7),
  (v_rrhh, 'Exposición por anticipos al personal', 'Consolida anticipos de sueldo y beneficios equivalentes frente a la capacidad de recupero.', 'Saldo pendiente de anticipos ÷ masa salarial neta × 100; casos fuera de política y antigüedad del saldo.', 'Proteger caja, evitar múltiples canales de crédito y priorizar excepciones justificadas.', '%', 'down', 8),
  (v_rrhh, 'Costo de incidentes internos atribuibles', 'Mide daños, choques, errores operativos o negligencias con costo para la empresa, por área y causa.', 'Costo de reparación o pérdida atribuible por período; cantidad de incidentes y recurrencia.', 'Corregir procesos, capacitación, custodia de activos y prevención de riesgos.', '$', 'down', 9);

  -- ADM. Y FINANZAS
  INSERT INTO kpis (area_id, name, definition, formula, decision, unit, target_direction, sort_order) VALUES
  (v_finan, 'Liquidez y disponibilidades', 'Expone caja, bancos, inversiones en cauciones y moneda extranjera, con fecha de disponibilidad y fondos comprometidos separados.', 'Disponible utilizable = suma de fondos aplicables al horizonte aprobado. Cobertura = disponible ÷ pagos de ese horizonte.', 'Anticipar restricciones de pago con una foto de fondos utilizables, no sólo con el ratio patrimonial.', '$', 'up', 1),
  (v_finan, 'Endeudamiento total por origen', 'Muestra saldos por RCI, bancos, cheques diferidos negociados, proveedores y otros pasivos, diferenciando deuda financiera y vencimientos.', 'Suma de obligaciones sin duplicación; deuda por origen ÷ deuda total × 100.', 'Priorizar pagos y revisar concentración, vencimientos y respaldo; no reducir todo el endeudamiento a autos debidos.', '$', 'down', 2),
  (v_finan, 'Rentabilidad: margen neto por actividad y total', 'Mide el resultado de VN, VU, RE, SE y PR después de costos, gastos e impuestos asignados; muestra el total de la empresa.', 'Resultado neto de actividad ÷ ingresos netos de actividad × 100. Total = resultado neto empresa ÷ ingresos netos empresa × 100.', 'Identificar actividades deficitarias y evaluar el resultado después de estructura y financiación.', '%', 'up', 3),
  (v_finan, 'Costos de estructura por unidad de negocio y sucursal', 'Expone gastos fijos operativos por rubro, actividad y sucursal, distinguiendo imputaciones directas de gastos comunes distribuidos.', 'Gastos fijos devengados; incidencia = gastos fijos ÷ ingresos netos × 100.', 'Evaluar tamaño y costo de la estructura, evitando confundir menor venta con mayor gasto absoluto.', '$', 'down', 4),
  (v_finan, 'Costos financieros', 'Mide intereses, comisiones y cargos de financiación, por instrumento y origen, con sus tasas y plazos.', 'Intereses + cargos de financiación devengados; incidencia sobre ingresos netos × 100.', 'Relacionar deuda y costo del mes; revisar instrumentos y condiciones de financiación.', '$', 'down', 5),
  (v_finan, 'Días o meses de inventarios: VN, VU y RE', 'Mide cobertura al ritmo reciente de ventas o consumo, con tres resultados separados y la ventana de cálculo informada.', 'Días = inventario al cierre a costo ÷ costo diario promedio de ventas/consumo; meses = inventario a costo ÷ costo mensual promedio.', 'Ajustar compras y salida de stock.', 'días', 'down', 6),
  (v_finan, 'Absorción de Postventa', 'Mide qué proporción de los gastos fijos de toda la empresa cubre la contribución de Repuestos y Servicios.', '(Contribución RE + contribución SE) ÷ gastos fijos operativos totales × 100.', 'Relacionar el aporte de Postventa con la estructura total.', '%', 'up', 7),
  (v_finan, 'Créditos a cobrar', 'Completa la foto patrimonial con cuentas corrientes, trámites de gestoría/patentamiento y liquidaciones de tarjetas pendientes de cobro.', 'Suma de saldos por cobrar sin duplicación; apertura vigente/vencido y fecha esperada de acreditación.', 'Priorizar cobranza y anticipar fondos, distinguiendo ventas realizadas de dinero efectivamente disponible.', '$', 'down', 8);
END $$;/*
# Seed KPI Data Values, Monthly Series, and Breakdowns

For each KPI, inserts:
- kpi_data row with current_value, target_value, previous_value, trend, and 6-month series
- kpi_breakdowns rows with detailed sub-data (vendedores, modelos, canales, etc.)
Uses a DO block to generate realistic sample values per KPI.
*/

DO $$
DECLARE
  k RECORD;
  v_current numeric;
  v_target numeric;
  v_prev numeric;
  v_trend text;
  v_series jsonb;
  v_months text[] := ARRAY['Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep'];
  v_vals numeric[];
  i int;
  v_breakdown_label text;
  v_breakdown_val numeric;
  v_bd_count int;
BEGIN
  FOR k IN SELECT id, target_direction, sort_order, area_id FROM kpis ORDER BY id LOOP
    -- Generate pseudo-random but deterministic values based on sort_order
    v_target := CASE
      WHEN k.target_direction = 'up' THEN 85 + (k.sort_order % 15)
      ELSE 5 + (k.sort_order % 10)
    END;

    v_current := CASE
      WHEN k.target_direction = 'up' THEN 60 + (k.sort_order % 35) + (random() * 10)::int
      ELSE 3 + (k.sort_order % 8) + (random() * 3)::int
    END;
    v_current := round(v_current::numeric, 1);

    v_prev := CASE
      WHEN k.target_direction = 'up' THEN v_current - (random() * 8)::int + 2
      ELSE v_current + (random() * 4)::int - 1
    END;
    v_prev := round(v_prev::numeric, 1);

    IF k.target_direction = 'up' THEN
      v_trend := CASE WHEN v_current > v_prev THEN 'up' WHEN v_current < v_prev THEN 'down' ELSE 'stable' END;
    ELSE
      v_trend := CASE WHEN v_current < v_prev THEN 'up' WHEN v_current > v_prev THEN 'down' ELSE 'stable' END;
    END IF;

    -- Build 6-month series
    v_vals := ARRAY[]::numeric[];
    FOR i IN 1..6 LOOP
      IF k.target_direction = 'up' THEN
        v_vals := array_append(v_vals, round((v_prev - 5 + i * 2 + (random() * 4 - 2))::numeric, 1));
      ELSE
        v_vals := array_append(v_vals, round((v_prev + 5 - i * 1 + (random() * 3 - 1.5))::numeric, 1));
      END IF;
    END LOOP;

    v_series := jsonb_build_array(
      jsonb_build_object('month', v_months[1], 'value', v_vals[1]),
      jsonb_build_object('month', v_months[2], 'value', v_vals[2]),
      jsonb_build_object('month', v_months[3], 'value', v_vals[3]),
      jsonb_build_object('month', v_months[4], 'value', v_vals[4]),
      jsonb_build_object('month', v_months[5], 'value', v_vals[5]),
      jsonb_build_object('month', v_months[6], 'value', v_vals[6])
    );

    INSERT INTO kpi_data (kpi_id, current_value, target_value, previous_value, trend, series, updated_at)
    VALUES (k.id, v_current, v_target, v_prev, v_trend, v_series, now())
    ON CONFLICT DO NOTHING;

    -- Add a few breakdowns per KPI
    v_bd_count := 3 + (k.sort_order % 3);
    FOR i IN 1..v_bd_count LOOP
      v_breakdown_label := CASE i
        WHEN 1 THEN 'Sucursal Centro'
        WHEN 2 THEN 'Sucursal Norte'
        WHEN 3 THEN 'Sucursal Sur'
        WHEN 4 THEN 'Online'
        WHEN 5 THEN 'Referidos'
      END;
      v_breakdown_val := round((v_current * (0.6 + random() * 0.6))::numeric, 1);
      INSERT INTO kpi_breakdowns (kpi_id, label, value, target, sort_order)
      VALUES (k.id, v_breakdown_label, v_breakdown_val, v_target, i)
      ON CONFLICT DO NOTHING;
    END LOOP;
  END LOOP;
END $$;/*
# User Management, Roles, and Data Entry Schema

## Overview
Adds authentication-based user management with three roles (admin, gerente, operador),
per-operator area permissions, and a data_entries table for operators to input
the raw values that feed each KPI.

## New Tables

1. `profiles` — Extends Supabase auth.users with role and display info
   - `id` (uuid, FK to auth.users, PK)
   - `email` (text)
   - `full_name` (text)
   - `role` (text: 'admin' | 'gerente' | 'operador')
   - `active` (boolean, default true)
   - `created_at` (timestamptz)

2. `user_areas` — Links operators to the areas they can access
   - `id` (uuid, PK)
   - `user_id` (uuid, FK to profiles)
   - `area_id` (uuid, FK to areas)
   - `created_at` (timestamptz)
   - Unique constraint on (user_id, area_id)

3. `data_entries` — Raw data inputs by operators for each KPI
   - `id` (uuid, PK)
   - `kpi_id` (uuid, FK to kpis)
   - `user_id` (uuid, FK to profiles, defaults to auth.uid())
   - `value` (numeric, the entered value)
   - `entry_date` (date, the period the value refers to)
   - `notes` (text, optional)
   - `created_at` (timestamptz)

## Security
- RLS enabled on all new tables
- profiles: authenticated users can read all profiles; only admin can insert/update/delete
- user_areas: authenticated can read; only admin can insert/update/delete
- data_entries: authenticated can read all; authenticated users can insert their own;
  admin can delete any; users can update/delete their own
- Existing areas/kpis/kpi_data/kpi_breakdowns tables: policies updated to TO authenticated
  (previously anon+authenticated) since the app now requires sign-in
*/

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL DEFAULT 'operador' CHECK (role IN ('admin', 'gerente', 'operador')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read profiles (needed to see who entered data)
DROP POLICY IF EXISTS "auth_select_profiles" ON profiles;
CREATE POLICY "auth_select_profiles" ON profiles FOR SELECT
  TO authenticated USING (true);

-- Only admin can insert profiles
DROP POLICY IF EXISTS "admin_insert_profiles" ON profiles;
CREATE POLICY "admin_insert_profiles" ON profiles FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Only admin can update profiles
DROP POLICY IF EXISTS "admin_update_profiles" ON profiles;
CREATE POLICY "admin_update_profiles" ON profiles FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Only admin can delete profiles
DROP POLICY IF EXISTS "admin_delete_profiles" ON profiles;
CREATE POLICY "admin_delete_profiles" ON profiles FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- USER_AREAS TABLE (operator area permissions)
-- ============================================================
CREATE TABLE IF NOT EXISTS user_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  area_id uuid NOT NULL REFERENCES areas(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE (user_id, area_id)
);

ALTER TABLE user_areas ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read user_areas
DROP POLICY IF EXISTS "auth_select_user_areas" ON user_areas;
CREATE POLICY "auth_select_user_areas" ON user_areas FOR SELECT
  TO authenticated USING (true);

-- Only admin can insert
DROP POLICY IF EXISTS "admin_insert_user_areas" ON user_areas;
CREATE POLICY "admin_insert_user_areas" ON user_areas FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Only admin can update
DROP POLICY IF EXISTS "admin_update_user_areas" ON user_areas;
CREATE POLICY "admin_update_user_areas" ON user_areas FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Only admin can delete
DROP POLICY IF EXISTS "admin_delete_user_areas" ON user_areas;
CREATE POLICY "admin_delete_user_areas" ON user_areas FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- DATA_ENTRIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS data_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id uuid NOT NULL REFERENCES kpis(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  value numeric NOT NULL DEFAULT 0,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_data_entries_kpi_id ON data_entries(kpi_id);
CREATE INDEX IF NOT EXISTS idx_data_entries_entry_date ON data_entries(entry_date);

ALTER TABLE data_entries ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read all data entries
DROP POLICY IF EXISTS "auth_select_data_entries" ON data_entries;
CREATE POLICY "auth_select_data_entries" ON data_entries FOR SELECT
  TO authenticated USING (true);

-- Any authenticated user can insert their own entries
DROP POLICY IF EXISTS "auth_insert_data_entries" ON data_entries;
CREATE POLICY "auth_insert_data_entries" ON data_entries FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- Users can update their own entries; admin can update any
DROP POLICY IF EXISTS "auth_update_data_entries" ON data_entries;
CREATE POLICY "auth_update_data_entries" ON data_entries FOR UPDATE
  TO authenticated USING (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- Users can delete their own entries; admin can delete any
DROP POLICY IF EXISTS "auth_delete_data_entries" ON data_entries;
CREATE POLICY "auth_delete_data_entries" ON data_entries FOR DELETE
  TO authenticated USING (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- Update existing tables' policies from anon to authenticated
-- (app now requires sign-in)
-- ============================================================

-- areas
DROP POLICY IF EXISTS "anon_crud_areas" ON areas;
DROP POLICY IF EXISTS "auth_select_areas" ON areas;
CREATE POLICY "auth_select_areas" ON areas FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_areas" ON areas;
CREATE POLICY "auth_insert_areas" ON areas FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "auth_update_areas" ON areas;
CREATE POLICY "auth_update_areas" ON areas FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "auth_delete_areas" ON areas;
CREATE POLICY "auth_delete_areas" ON areas FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- kpis
DROP POLICY IF EXISTS "anon_crud_kpis" ON kpis;
DROP POLICY IF EXISTS "auth_select_kpis" ON kpis;
CREATE POLICY "auth_select_kpis" ON kpis FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_kpis" ON kpis;
CREATE POLICY "auth_insert_kpis" ON kpis FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "auth_update_kpis" ON kpis;
CREATE POLICY "auth_update_kpis" ON kpis FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "auth_delete_kpis" ON kpis;
CREATE POLICY "auth_delete_kpis" ON kpis FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- kpi_data
DROP POLICY IF EXISTS "anon_crud_kpi_data" ON kpi_data;
DROP POLICY IF EXISTS "auth_select_kpi_data" ON kpi_data;
CREATE POLICY "auth_select_kpi_data" ON kpi_data FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_kpi_data" ON kpi_data;
CREATE POLICY "auth_insert_kpi_data" ON kpi_data FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'operador'))
  );

DROP POLICY IF EXISTS "auth_update_kpi_data" ON kpi_data;
CREATE POLICY "auth_update_kpi_data" ON kpi_data FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'operador'))
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'operador'))
  );

DROP POLICY IF EXISTS "auth_delete_kpi_data" ON kpi_data;
CREATE POLICY "auth_delete_kpi_data" ON kpi_data FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- kpi_breakdowns
DROP POLICY IF EXISTS "anon_crud_kpi_breakdowns" ON kpi_breakdowns;
DROP POLICY IF EXISTS "anon_select_kpi_breakdowns" ON kpi_breakdowns;
DROP POLICY IF EXISTS "auth_select_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "auth_select_kpi_breakdowns" ON kpi_breakdowns FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "auth_insert_kpi_breakdowns" ON kpi_breakdowns FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'operador'))
  );

DROP POLICY IF EXISTS "auth_update_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "auth_update_kpi_breakdowns" ON kpi_breakdowns FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'operador'))
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'operador'))
  );

DROP POLICY IF EXISTS "auth_delete_kpi_breakdowns" ON kpi_breakdowns;
CREATE POLICY "auth_delete_kpi_breakdowns" ON kpi_breakdowns FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- Trigger: auto-create profile on auth user signup
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 'operador')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();/*
# Fix handle_new_user trigger function

The trigger that auto-creates a profile on signup was failing with
"Database error saving new user" because it lacked a secure search_path
and the SECURITY DEFINER function could fail in certain RLS contexts.

## Changes
- Recreate handle_new_user with explicit search_path
- Ensure it runs as SECURITY DEFINER with bypass RLS
*/

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 'operador')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();/*
# Custom Fields, Formulas, API Connections, Firecrawl, Data Source Config

## Overview
Adds infrastructure for:
1. Custom fields that admins create and assign to areas + KPIs
2. Field values submitted by operators during data entry
3. Custom formulas that compute derived values from fields
4. API connections to external systems
5. Firecrawl connections for web scraping
6. Per-KPI data source configuration (operator, external, or both)

## New Tables

1. `custom_fields` — Admin-defined fields attached to areas/KPIs
   - id, area_id (FK), kpi_id (FK nullable), name, label, field_type, sort_order, created_at

2. `field_values` — Values submitted by operators for custom fields
   - id, field_id (FK), user_id (FK), value_text, value_number, value_date, entry_date, created_at

3. `formulas` — Custom formulas that compute from custom fields
   - id, kpi_id (FK), name, expression, field_mapping (jsonb), sort_order, created_at

4. `api_connections` — External API connection configs
   - id, name, base_url, auth_type, auth_config (jsonb), is_active, created_at

5. `firecrawl_connections` — Firecrawl web scraping configs
   - id, name, target_url, credentials (jsonb), is_active, created_at

6. `data_source_config` — Per-KPI config: where data comes from
   - id, kpi_id (FK unique), source_type ('operator', 'external', 'both'), created_at

## Security
- RLS enabled on all new tables
- Admin-only for create/update/delete on all config tables
- All authenticated users can read custom_fields, field_values, formulas
- api_connections and firecrawl_connections: admin-only read/write (sensitive credentials)
- data_source_config: admin-only write, authenticated read
*/

-- ============================================================
-- CUSTOM FIELDS
-- ============================================================
CREATE TABLE IF NOT EXISTS custom_fields (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  area_id uuid NOT NULL REFERENCES areas(id) ON DELETE CASCADE,
  kpi_id uuid REFERENCES kpis(id) ON DELETE CASCADE,
  name text NOT NULL,
  label text NOT NULL,
  field_type text NOT NULL DEFAULT 'text' CHECK (field_type IN ('text', 'numeric', 'date', 'datetime', 'boolean', 'select', 'textarea')),
  options jsonb DEFAULT '[]'::jsonb,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_custom_fields_area_id ON custom_fields(area_id);
CREATE INDEX IF NOT EXISTS idx_custom_fields_kpi_id ON custom_fields(kpi_id);

ALTER TABLE custom_fields ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_custom_fields" ON custom_fields;
CREATE POLICY "auth_select_custom_fields" ON custom_fields FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_custom_fields" ON custom_fields;
CREATE POLICY "admin_insert_custom_fields" ON custom_fields FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_update_custom_fields" ON custom_fields;
CREATE POLICY "admin_update_custom_fields" ON custom_fields FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_delete_custom_fields" ON custom_fields;
CREATE POLICY "admin_delete_custom_fields" ON custom_fields FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- FIELD VALUES
-- ============================================================
CREATE TABLE IF NOT EXISTS field_values (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  field_id uuid NOT NULL REFERENCES custom_fields(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  value_text text DEFAULT '',
  value_number numeric,
  value_date timestamptz,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_field_values_field_id ON field_values(field_id);
CREATE INDEX IF NOT EXISTS idx_field_values_entry_date ON field_values(entry_date);

ALTER TABLE field_values ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_field_values" ON field_values;
CREATE POLICY "auth_select_field_values" ON field_values FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_insert_field_values" ON field_values;
CREATE POLICY "auth_insert_field_values" ON field_values FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "auth_update_field_values" ON field_values;
CREATE POLICY "auth_update_field_values" ON field_values FOR UPDATE
  TO authenticated USING (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "auth_delete_field_values" ON field_values;
CREATE POLICY "auth_delete_field_values" ON field_values FOR DELETE
  TO authenticated USING (
    auth.uid() = user_id
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- FORMULAS
-- ============================================================
CREATE TABLE IF NOT EXISTS formulas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id uuid NOT NULL REFERENCES kpis(id) ON DELETE CASCADE,
  name text NOT NULL,
  expression text NOT NULL,
  field_mapping jsonb NOT NULL DEFAULT '{}'::jsonb,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_formulas_kpi_id ON formulas(kpi_id);

ALTER TABLE formulas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_formulas" ON formulas;
CREATE POLICY "auth_select_formulas" ON formulas FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_formulas" ON formulas;
CREATE POLICY "admin_insert_formulas" ON formulas FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_update_formulas" ON formulas;
CREATE POLICY "admin_update_formulas" ON formulas FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_delete_formulas" ON formulas;
CREATE POLICY "admin_delete_formulas" ON formulas FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- API CONNECTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS api_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  base_url text NOT NULL,
  auth_type text NOT NULL DEFAULT 'bearer' CHECK (auth_type IN ('bearer', 'api_key', 'basic', 'none')),
  auth_config jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE api_connections ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_select_api_connections" ON api_connections;
CREATE POLICY "admin_select_api_connections" ON api_connections FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_insert_api_connections" ON api_connections;
CREATE POLICY "admin_insert_api_connections" ON api_connections FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_update_api_connections" ON api_connections;
CREATE POLICY "admin_update_api_connections" ON api_connections FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_delete_api_connections" ON api_connections;
CREATE POLICY "admin_delete_api_connections" ON api_connections FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- FIRECRAWL CONNECTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS firecrawl_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  target_url text NOT NULL,
  credentials jsonb NOT NULL DEFAULT '{}'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE firecrawl_connections ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_select_firecrawl_connections" ON firecrawl_connections;
CREATE POLICY "admin_select_firecrawl_connections" ON firecrawl_connections FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_insert_firecrawl_connections" ON firecrawl_connections;
CREATE POLICY "admin_insert_firecrawl_connections" ON firecrawl_connections FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_update_firecrawl_connections" ON firecrawl_connections;
CREATE POLICY "admin_update_firecrawl_connections" ON firecrawl_connections FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_delete_firecrawl_connections" ON firecrawl_connections;
CREATE POLICY "admin_delete_firecrawl_connections" ON firecrawl_connections FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

-- ============================================================
-- DATA SOURCE CONFIG (per KPI)
-- ============================================================
CREATE TABLE IF NOT EXISTS data_source_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id uuid NOT NULL UNIQUE REFERENCES kpis(id) ON DELETE CASCADE,
  source_type text NOT NULL DEFAULT 'operator' CHECK (source_type IN ('operator', 'external', 'both')),
  api_connection_id uuid REFERENCES api_connections(id) ON DELETE SET NULL,
  firecrawl_connection_id uuid REFERENCES firecrawl_connections(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_data_source_config_kpi_id ON data_source_config(kpi_id);

ALTER TABLE data_source_config ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_data_source_config" ON data_source_config;
CREATE POLICY "auth_select_data_source_config" ON data_source_config FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_data_source_config" ON data_source_config;
CREATE POLICY "admin_insert_data_source_config" ON data_source_config FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_update_data_source_config" ON data_source_config;
CREATE POLICY "admin_update_data_source_config" ON data_source_config FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_delete_data_source_config" ON data_source_config;
CREATE POLICY "admin_delete_data_source_config" ON data_source_config FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );CREATE TABLE IF NOT EXISTS griba_leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id text,
  name text,
  email text,
  phone text,
  source text,
  status text DEFAULT 'nuevo',
  vehicle_interest text,
  notes text,
  raw_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  fetched_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_griba_leads_status ON griba_leads(status);
CREATE INDEX IF NOT EXISTS idx_griba_leads_external_id ON griba_leads(external_id);

ALTER TABLE griba_leads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_griba_leads" ON griba_leads;
CREATE POLICY "auth_select_griba_leads" ON griba_leads FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_griba_leads" ON griba_leads;
CREATE POLICY "admin_insert_griba_leads" ON griba_leads FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_update_griba_leads" ON griba_leads;
CREATE POLICY "admin_update_griba_leads" ON griba_leads FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "admin_delete_griba_leads" ON griba_leads;
CREATE POLICY "admin_delete_griba_leads" ON griba_leads FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );-- Allow gerente to also insert/update/delete griba_leads
DROP POLICY IF EXISTS "admin_insert_griba_leads" ON griba_leads;
DROP POLICY IF EXISTS "admin_update_griba_leads" ON griba_leads;
DROP POLICY IF EXISTS "admin_delete_griba_leads" ON griba_leads;

CREATE POLICY "manager_insert_griba_leads" ON griba_leads FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  );

CREATE POLICY "manager_update_griba_leads" ON griba_leads FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  );

CREATE POLICY "manager_delete_griba_leads" ON griba_leads FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  );-- Allow gerente to also read api_connections (needed for GribaInfo module)
DROP POLICY IF EXISTS "admin_select_api_connections" ON api_connections;
CREATE POLICY "manager_select_api_connections" ON api_connections FOR SELECT
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  );ALTER TABLE api_connections ADD COLUMN IF NOT EXISTS api_key text;/*
# Create notifications table

1. New Tables
- `notifications`
  - id (uuid, primary key)
  - user_id (uuid, FK to auth.users) — the user who triggered the notification (the operator)
  - target_role (text) — 'gerente' or 'admin' (who should see it)
  - area_id (uuid, FK to areas, nullable) — which area the change relates to
  - kpi_id (uuid, FK to kpis, nullable) — which KPI the change relates to
  - action (text) — 'create' or 'update' or 'delete'
  - message (text) — human-readable description
  - is_read (boolean, default false)
  - created_at (timestamptz)

2. Security
- RLS enabled on `notifications`.
- SELECT: gerente and admin can read notifications targeted to their role.
- INSERT: any authenticated user can insert (operators create notifications when they modify data).
- DELETE: gerente and admin can delete notifications (to clear read ones).
- UPDATE: gerente and admin can mark notifications as read.
*/

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  target_role text NOT NULL DEFAULT 'gerente',
  area_id uuid REFERENCES areas(id) ON DELETE SET NULL,
  kpi_id uuid REFERENCES kpis(id) ON DELETE SET NULL,
  action text NOT NULL,
  message text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_notifications_for_managers" ON notifications;
CREATE POLICY "select_notifications_for_managers"
ON notifications FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid()
    AND p.role IN ('gerente', 'admin')
    AND p.role = notifications.target_role
  )
  OR user_id = auth.uid()
);

DROP POLICY IF EXISTS "insert_notifications_any_authenticated" ON notifications;
CREATE POLICY "insert_notifications_any_authenticated"
ON notifications FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_notifications_for_managers" ON notifications;
CREATE POLICY "update_notifications_for_managers"
ON notifications FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid()
    AND p.role IN ('gerente', 'admin')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid()
    AND p.role IN ('gerente', 'admin')
  )
);

DROP POLICY IF EXISTS "delete_notifications_for_managers" ON notifications;
CREATE POLICY "delete_notifications_for_managers"
ON notifications FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = auth.uid()
    AND p.role IN ('gerente', 'admin')
  )
);

CREATE INDEX IF NOT EXISTS idx_notifications_target_role_created_at
ON notifications (target_role, created_at DESC);
/*
# Add result_field_id to formulas and field_role to custom_fields

1. Changes to `formulas` table:
- Add `result_field_id` (uuid, nullable, FK to custom_fields) — stores which custom field the formula result is saved into.

2. Changes to `custom_fields` table:
- Add `field_role` (text, default 'input') — 'input' for blue input fields, 'result' for red result fields.

3. Security:
- No policy changes needed; existing policies cover the new columns.
*/

ALTER TABLE formulas ADD COLUMN IF NOT EXISTS result_field_id uuid REFERENCES custom_fields(id) ON DELETE SET NULL;

ALTER TABLE custom_fields ADD COLUMN IF NOT EXISTS field_role text NOT NULL DEFAULT 'input';

DROP POLICY IF EXISTS "select_formulas_authenticated" ON formulas;
CREATE POLICY "select_formulas_authenticated"
ON formulas FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_formulas_admin" ON formulas;
CREATE POLICY "insert_formulas_admin"
ON formulas FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);

DROP POLICY IF EXISTS "update_formulas_admin" ON formulas;
CREATE POLICY "update_formulas_admin"
ON formulas FOR UPDATE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
)
WITH CHECK (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);

DROP POLICY IF EXISTS "delete_formulas_admin" ON formulas;
CREATE POLICY "delete_formulas_admin"
ON formulas FOR DELETE
TO authenticated
USING (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);
/*
# Add customizable area card colors

## Overview
Adds a persistent color value to each business area so administrators can create and visually organize dashboard cards without changing existing KPI data.

## Modified Tables
- `areas.color` — hex color used for the area card and navigation accent; existing areas receive a blue default.

## Security
- The existing `areas` table remains protected by its current anon + authenticated CRUD policies for this shared dashboard.
- No data is deleted, renamed, or retyped.

## Important Notes
1. Existing areas keep their current names, icons, descriptions, KPIs, and order.
2. New areas may use any valid hex color selected in the administrator screen.
*/

ALTER TABLE public.areas
  ADD COLUMN IF NOT EXISTS color text NOT NULL DEFAULT '#2563eb';
/*
# Add results_json and inputs_json to data_entries

1. Changes to `data_entries` table:
- Add `results_json` (jsonb, nullable) — stores ALL computed result field values for this entry
- Add `inputs_json` (jsonb, nullable) — stores ALL input field values submitted by the user

2. Purpose:
- Previously, data_entries only stored a single `value` (the first result field).
- Now every result field value is saved as a JSON map: { field_id: { label, value } }
- Input field values are also saved so the history can show what was entered.
- The single `value` column remains for backwards compatibility (set to the first result).

3. Security:
- No policy changes needed; existing policies cover the new columns.
*/

ALTER TABLE data_entries ADD COLUMN IF NOT EXISTS results_json jsonb DEFAULT '{}'::jsonb;
ALTER TABLE data_entries ADD COLUMN IF NOT EXISTS inputs_json jsonb DEFAULT '{}'::jsonb;/*
# Add color column to custom_fields

1. Modified Tables
- `custom_fields`: add `color` (text, default 'emerald') to allow choosing the
  card color shown in the dashboard for result fields. Defaults to green.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'custom_fields' AND column_name = 'color'
  ) THEN
    ALTER TABLE custom_fields ADD COLUMN color text NOT NULL DEFAULT 'emerald';
  END IF;
END $$;
/*
# Add per-field display units

1. Modified Tables
- `custom_fields`: add `unit` (text, default '%') so every result field can
  define independently how its calculated value is displayed.

2. Compatibility
- Existing custom fields receive the percentage default without changing or
  deleting any existing data.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'custom_fields' AND column_name = 'unit'
  ) THEN
    ALTER TABLE custom_fields ADD COLUMN unit text NOT NULL DEFAULT '%';
  END IF;
END $$;
/*
# Add visibility flags to custom_fields

1. Modified Tables
- `custom_fields`: add `hidden_in_entry` (boolean, default false) and
  `hidden_in_dashboard` (boolean, default false) so each field can be
  independently hidden from the data entry form and/or the dashboard.

2. Compatibility
- Existing fields default to visible in both places (false), preserving
  current behavior without changing or deleting any existing data.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'custom_fields' AND column_name = 'hidden_in_entry'
  ) THEN
    ALTER TABLE custom_fields ADD COLUMN hidden_in_entry boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'custom_fields' AND column_name = 'hidden_in_dashboard'
  ) THEN
    ALTER TABLE custom_fields ADD COLUMN hidden_in_dashboard boolean NOT NULL DEFAULT false;
  END IF;
END $$;
/*
# Create asofix_metrics table

## Overview
Stores the six management metrics synced from Asófix Producción (Google Service Account).
Each row is one metric (identified by `metric_key`) with its current value and the timestamp
of the last sync. The frontend reads these rows to display live data in the
"Conversión de leads y efectividad por canal y punto de venta" KPI card.

## New Tables
- `asofix_metrics`
  - `id` (uuid, primary key)
  - `metric_key` (text, unique) — machine-readable key (e.g. "leads_nuevos")
  - `label` (text) — human-readable label shown in the UI
  - `value` (text) — the value as displayed by Asófix (may include %, "hs", etc.)
  - `synced_at` (timestamptz) — when the value was last fetched from Asófix

## Security
- RLS enabled
- All authenticated users can read (dashboard is shared across roles)
- Only admin/gerente can write (sync is triggered server-side via edge function
  using the service role key, which bypasses RLS)
*/

CREATE TABLE IF NOT EXISTS asofix_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_key text UNIQUE NOT NULL,
  label text NOT NULL,
  value text NOT NULL DEFAULT '',
  synced_at timestamptz DEFAULT now()
);

ALTER TABLE asofix_metrics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_asofix_metrics" ON asofix_metrics;
CREATE POLICY "auth_select_asofix_metrics" ON asofix_metrics FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_asofix_metrics" ON asofix_metrics;
CREATE POLICY "admin_insert_asofix_metrics" ON asofix_metrics FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  );

DROP POLICY IF EXISTS "admin_update_asofix_metrics" ON asofix_metrics;
CREATE POLICY "admin_update_asofix_metrics" ON asofix_metrics FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role IN ('admin', 'gerente'))
  );

-- Seed initial values so the card shows data before the first sync
INSERT INTO asofix_metrics (metric_key, label, value) VALUES
  ('leads_nuevos',           'Cantidad de leads nuevos',           '722'),
  ('cierres_exitosos',       'Cantidad de cierres exitosos',       '46'),
  ('leads_en_gestion',       'Leads en gestión',                   '202'),
  ('cierres_perdidos',       'Cantidad de cierres perdidos',       '638'),
  ('conversion_mes_anterior','Tasa de conversión del mes anterior', '5,99%'),
  ('tiempo_primer_contacto', 'Tiempo promedio del primer contacto', '05:43 hs')
ON CONFLICT (metric_key) DO NOTHING;

-- ============================================
-- PART 2: DATA (INSERT statements)
-- ============================================
-- ============================================
-- COMPLETE DATA INSERT STATEMENTS
-- Ruiz Automotores KPI Dashboard
-- Generated: 2026-10-01
-- ============================================

-- ============================================
-- areas (7 rows)
-- ============================================
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('5fe5c3f4-3916-4bfd-8667-c97f910b84f1', 'ventas-0km', 'Ventas 0 km', 'Car', 'Vehículos nuevos: cumplimiento, conversión, margen y productividad comercial.', 0, '2026-09-21 13:24:46.67147+00', '#059669'), ('4fd887ff-d654-4b33-81d4-f43b5b73feee', 'plan-rombo', 'Plan Rombo', 'TrendingUp', 'Suscripciones, cartera, adjudicaciones y aporte económico del plan de ahorro.', 1, '2026-09-21 13:24:46.67147+00', '#ca8a04'), ('03daee6c-d94c-475f-ad81-7bf671a6104b', 'mi-auto-ya', 'Mi Auto Ya!', 'RefreshCw', 'Usados: compra, peritaje, preparación, rotación de stock y venta.', 2, '2026-09-21 13:24:46.67147+00', '#ea580c'), ('f6b9e6c1-179b-421a-98d4-f5e0511f1925', 'postventa', 'Postventa', 'Wrench', 'Taller, repuestos, stock, agenda y cumplimiento de compras a Renault.', 3, '2026-09-21 13:24:46.67147+00', '#dc2626'), ('aa43fcb6-f31c-449d-9bc7-19a092118f1d', 'calidad', 'Calidad', 'ShieldCheck', 'Mystery Shopping, NPS, DDA, OCV, Hot Alert e incentivos de calidad.', 4, '2026-09-21 13:24:46.67147+00', '#0284c7'), ('d6ac25af-e768-4a2c-a7ef-b0230cd5ad0f', 'rrhh', 'Recursos Humanos', 'Users', 'Ausentismo, rotación, costo de personal y gestión disciplinaria.', 5, '2026-09-21 13:24:46.67147+00', '#1e40af'), ('69ff6d56-f25f-4640-a18d-b599df895d5d', 'admn-finanzas', 'Administración y Finanzas', 'Landmark', 'Liquidez, endeudamiento, rentabilidad, costos y créditos a cobrar.', 6, '2026-09-21 13:24:46.67147+00', '#991b1b');

-- ============================================
-- profiles (7 rows)
-- ============================================
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('4cb795e8-ed86-4906-94c8-e4a500a4177e', 'guillodc74@hotmail.com', 'Guillermo Contrastato', 'admin', true, '2026-09-21 14:00:41.489051+00'), ('6bf9f8d7-7aa0-45e9-8ce8-ee8631af5220', 'diegosolorzano@ruizsa.com.ar', 'Diego Solórzano', 'gerente', true, '2026-09-21 14:04:36.95538+00'), ('1b724af6-4e80-42ab-bae5-8207ab8725d5', 'rcruz@ruizsa.com.ar', 'Rodolfo Cruz', 'operador', true, '2026-09-21 14:05:05.567332+00'), ('68d32c7b-d95f-47a6-a6a0-b4bab56100f2', 'anicola@ruizsa.com.ar', 'Antonela Nicola', 'operador', true, '2026-09-21 14:05:29.482976+00'), ('4845f22c-aef4-4e42-be93-ef3664dec109', 'agimenez@ruizsa.com.ar', 'Alvaro Giménez', 'operador', true, '2026-09-21 14:06:26.813638+00'), ('ac91044f-d56a-467c-ad28-e8b4f12fa509', 'lucianaconsolani@ruizsa.com.ar', 'Luciana Consolani', 'operador', true, '2026-09-21 14:40:57.965395+00'), ('592a1a74-c21d-4bcc-9b3f-29d59e50f425', 'rrhh@ruizsa.com.ar', 'Germán Albornóz', 'operador', true, '2026-09-21 14:41:34.757711+00');

-- ============================================
-- user_areas (5 rows)
-- ============================================
INSERT INTO user_areas (id, user_id, area_id, created_at) VALUES ('2f95d034-472b-4d81-99b3-c00af545f0f6', '1b724af6-4e80-42ab-bae5-8207ab8725d5', '5fe5c3f4-3916-4bfd-8667-c97f910b84f1', '2026-09-21 14:05:06.535202+00'), ('ba9a0324-b8fb-4e7f-96b3-09fdace5f2c4', '68d32c7b-d95f-47a6-a6a0-b4bab56100f2', 'f6b9e6c1-179b-421a-98d4-f5e0511f1925', '2026-09-21 14:39:55.361026+00'), ('aff7bdd3-d6ad-4782-9f96-a42553edd1b1', '4845f22c-aef4-4e42-be93-ef3664dec109', '4fd887ff-d654-4b33-81d4-f43b5b73feee', '2026-09-21 14:40:15.411149+00'), ('cd48186c-03b5-460f-b160-7235af22c0d7', 'ac91044f-d56a-467c-ad28-e8b4f12fa509', 'aa43fcb6-f31c-449d-9bc7-19a092118f1d', '2026-09-21 14:40:58.383084+00'), ('0f844dba-326e-449c-a7d1-98256be202d4', '592a1a74-c21d-4bcc-9b3f-29d59e50f425', 'd6ac25af-e768-4a2c-a7ef-b0230cd5ad0f', '2026-09-21 14:41:35.473337+00');

-- ============================================
-- asofix_metrics (6 rows)
-- ============================================
INSERT INTO asofix_metrics (id, metric_key, label, value, synced_at) VALUES ('54be967d-6aa5-49cd-87f6-4784f0a46aaa', 'cierres_exitosos', 'Cantidad de cierres exitosos', '46', '2026-09-29 13:53:52.669456+00'), ('c5ca678b-28a0-4837-8290-209b8c6a1f04', 'cierres_perdidos', 'Cantidad de cierres perdidos', '638', '2026-09-29 13:53:52.669456+00'), ('932c7388-e052-46e9-ba54-441c7e69964a', 'conversion_mes_anterior', 'Tasa de conversión del mes anterior', '5,99%', '2026-09-29 13:53:52.669456+00'), ('b2663701-ac0e-435c-8bb9-8287704e9b60', 'leads_en_gestion', 'Leads en gestión', '202', '2026-09-29 13:53:52.669456+00'), ('beb78d9e-b0ef-4f80-aa31-e25012dec9fe', 'leads_nuevos', 'Cantidad de leads nuevos', '722', '2026-09-29 13:53:52.669456+00'), ('b85aaf45-8495-4713-9ba1-2ad0f6822fa4', 'tiempo_primer_contacto', 'Tiempo promedio del primer contacto', '05:43 hs', '2026-09-29 13:53:52.669456+00');

-- ============================================
-- firecrawl_connections (1 row)
-- ============================================
INSERT INTO firecrawl_connections (id, name, target_url, credentials, is_active, created_at) VALUES ('f97fa1be-8083-4b13-ade8-8ed4e9dfa193', 'Griba', 'https://ruizcrm.griba.com.ar:64443/', '{"api_key": "fc-96ecf6ce6b304060a3ce30045a83426b", "password": "Admin2017FGHFG", "username": "gcontrastato"}'::jsonb, true, '2026-09-21 18:32:23.597995+00');

-- ============================================
-- data_source_config (1 row)
-- ============================================
INSERT INTO data_source_config (id, kpi_id, source_type, api_connection_id, firecrawl_connection_id, created_at) VALUES ('6814fd33-7e2b-44cf-b3b7-13944f35943d', '689281d2-8cdc-41d2-b6cf-cb8db518df97', 'external', NULL, 'f97fa1be-8083-4b13-ade8-8ed4e9dfa193', '2026-09-21 18:32:34.746313+00');

-- ============================================
-- notifications (5 rows)
-- ============================================
INSERT INTO notifications (id, user_id, target_role, area_id, kpi_id, action, message, is_read, created_at) VALUES ('fd6b088c-4594-4878-a256-e8199547abcc', '1b724af6-4e80-42ab-bae5-8207ab8725d5', 'gerente', '5fe5c3f4-3916-4bfd-8667-c97f910b84f1', '29422146-8620-4804-9b56-4ca85f4dc444', 'create', 'cargó datos en "Cumplimiento y tiempo de entrega"', false, '2026-09-25 17:36:07.852874+00'), ('c9dbea17-910a-48fe-a63c-950668296692', '1b724af6-4e80-42ab-bae5-8207ab8725d5', 'gerente', '5fe5c3f4-3916-4bfd-8667-c97f910b84f1', '311ccc80-8c46-4109-a7aa-b22f07245c6c', 'create', 'cargó datos en "Participación de mercado en Tucumán"', false, '2026-09-25 17:36:29.334474+00'), ('1c239d14-15cc-4768-8f03-4d92adda3c8b', '4845f22c-aef4-4e42-be93-ef3664dec109', 'gerente', '4fd887ff-d654-4b33-81d4-f43b5b73feee', 'b5759156-296a-4f79-8f36-0a7e67129025', 'create', 'cargó datos en "Cumplimiento del objetivo de suscripciones"', false, '2026-09-29 15:37:19.115221+00'), ('4a7936e2-658a-4b83-a54a-59186c5eb807', '4845f22c-aef4-4e42-be93-ef3664dec109', 'gerente', '4fd887ff-d654-4b33-81d4-f43b5b73feee', '3a51e47f-ee53-47a9-978e-9b6615b64aae', 'create', 'cargó datos en "Contribución económica mensual"', false, '2026-09-29 15:37:38.783302+00'), ('90524b2f-d84a-43ae-8057-475418d14827', '4845f22c-aef4-4e42-be93-ef3664dec109', 'gerente', '4fd887ff-d654-4b33-81d4-f43b5b73feee', 'c26b7f4b-82d3-43ff-b0ed-779f53694699', 'create', 'cargó datos en "Cartera activa y tasa de caída por cohorte"', false, '2026-09-29 15:37:54.652375+00');

-- ============================================
-- griba_leads (0 rows - table is empty)
-- ============================================
-- No data to insert.

-- ============================================
-- NOTE: The following tables have their data exported
-- in the companion JSON file due to size:
--   backups/database-backup-2026-10-01.json
--
-- Tables in JSON file:
--   kpis (61 rows)
--   kpi_data (61 rows)
--   kpi_breakdowns (245 rows)
--   custom_fields (64 rows)
--   formulas (23 rows)
--   data_entries (27 rows)
--   field_values (140 rows)
--   api_connections (3 rows)
-- ============================================
