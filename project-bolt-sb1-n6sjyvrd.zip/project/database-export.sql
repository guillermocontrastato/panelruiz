-- ============================================================================
-- KPI Dashboard - Export completo de datos
-- Fecha: 2026-09-28
-- ============================================================================
-- INSTRUCCIONES DE IMPORTACIÓN:
-- 1. Ejecutar primero todas las migraciones de la carpeta supabase/migrations/
--    (en orden por fecha) para crear el esquema completo.
-- 2. Ejecutar este archivo para insertar todos los datos.
-- 3. Las tablas auth.users no se incluyen aquí (se crean al registrar usuarios).
--    Los perfiles sí se incluyen con sus IDs originales.
-- ============================================================================

-- ============================================================================
-- Tabla: areas
-- ============================================================================
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('5fe5c3f4-3916-4bfd-8667-c97f910b84f1', 'ventas-0km', 'Ventas 0 km', 'Car', 'Vehículos nuevos: cumplimiento, conversión, margen y productividad comercial.', 0, '2026-09-21 13:24:46.67147+00', '#059669');
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('4fd887ff-d654-4b33-81d4-f43b5b73feee', 'plan-rombo', 'Plan Rombo', 'TrendingUp', 'Suscripciones, cartera, adjudicaciones y aporte económico del plan de ahorro.', 1, '2026-09-21 13:24:46.67147+00', '#ca8a04');
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('03daee6c-d94c-475f-ad81-7bf671a6104b', 'mi-auto-ya', 'Mi Auto Ya!', 'RefreshCw', 'Usados: compra, peritaje, preparación, rotación de stock y venta.', 2, '2026-09-21 13:24:46.67147+00', '#ea580c');
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('f6b9e6c1-179b-421a-98d4-f5e0511f1925', 'postventa', 'Postventa', 'Wrench', 'Taller, repuestos, stock, agenda y cumplimiento de compras a Renault.', 3, '2026-09-21 13:24:46.67147+00', '#dc2626');
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('aa43fcb6-f31c-449d-9bc7-19a092118f1d', 'calidad', 'Calidad', 'ShieldCheck', 'Mystery Shopping, NPS, DDA, OCV, Hot Alert e incentivos de calidad.', 4, '2026-09-21 13:24:46.67147+00', '#0284c7');
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('d6ac25af-e768-4a2c-a7ef-b0230cd5ad0f', 'rrhh', 'Recursos Humanos', 'Users', 'Ausentismo, rotación, costo de personal y gestión disciplinaria.', 5, '2026-09-21 13:24:46.67147+00', '#1e40af');
INSERT INTO areas (id, slug, name, icon, description, sort_order, created_at, color) VALUES ('69ff6d56-f25f-4640-a18d-b599df895d5d', 'admn-finanzas', 'Administración y Finanzas', 'Landmark', 'Liquidez, endeudamiento, rentabilidad, costos y créditos a cobrar.', 6, '2026-09-21 13:24:46.67147+00', '#991b1b');

-- ============================================================================
-- Tabla: profiles
-- ============================================================================
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('4cb795e8-ed86-4906-94c8-e4a500a4177e', 'guillodc74@hotmail.com', 'Guillermo Contrastato', 'admin', true, '2026-09-21 14:00:41.489051+00');
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('6bf9f8d7-7aa0-45e9-8ce8-ee8631af5220', 'diegosolorzano@ruizsa.com.ar', 'Diego Solórzano', 'gerente', true, '2026-09-21 14:04:36.95538+00');
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('68d32c7b-d95f-47a6-a6a0-b4bab56100f2', 'anicola@ruizsa.com.ar', 'Antonela Nicola', 'operador', true, '2026-09-21 14:05:29.482976+00');
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('1b724af6-4e80-42ab-bae5-8207ab8725d5', 'rcruz@ruizsa.com.ar', 'Rodolfo Cruz', 'operador', true, '2026-09-21 14:05:05.567332+00');
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('4845f22c-aef4-4e42-be93-ef3664dec109', 'agimenez@ruizsa.com.ar', 'Alvaro Giménez', 'operador', true, '2026-09-21 14:06:26.813638+00');
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('ac91044f-d56a-467c-ad28-e8b4f12fa509', 'lucianaconsolani@ruizsa.com.ar', 'Luciana Consolani', 'operador', true, '2026-09-21 14:40:57.965395+00');
INSERT INTO profiles (id, email, full_name, role, active, created_at) VALUES ('592a1a74-c21d-4bcc-9b3f-29d59e50f425', 'rrhh@ruizsa.com.ar', 'Germán Albornóz', 'operador', true, '2026-09-21 14:41:34.757711+00');

-- ============================================================================
-- Tabla: user_areas
-- ============================================================================
INSERT INTO user_areas (id, user_id, area_id) VALUES ('2f95d034-472b-4d81-99b3-c00af545f0f6', '1b724af6-4e80-42ab-bae5-8207ab8725d5', '5fe5c3f4-3916-4bfd-8667-c97f910b84f1');
INSERT INTO user_areas (id, user_id, area_id) VALUES ('ba9a0324-b8fb-4e7f-96b3-09fdace5f2c4', '68d32c7b-d95f-47a6-a6a0-b4bab56100f2', 'f6b9e6c1-179b-421a-98d4-f5e0511f1925');
INSERT INTO user_areas (id, user_id, area_id) VALUES ('aff7bdd3-d6ad-4782-9f96-a42553edd1b1', '4845f22c-aef4-4e42-be93-ef3664dec109', '4fd887ff-d654-4b33-81d4-f43b5b73feee');
INSERT INTO user_areas (id, user_id, area_id) VALUES ('cd48186c-03b5-460f-b160-7235af22c0d7', 'ac91044f-d56a-467c-ad28-e8b4f12fa509', 'aa43fcb6-f31c-449d-9bc7-19a092118f1d');
INSERT INTO user_areas (id, user_id, area_id) VALUES ('0f844dba-326e-449c-a7d1-98256be202d4', '592a1a74-c21d-4bcc-9b3f-29d59e50f425', 'd6ac25af-e768-4a2c-a7ef-b0230cd5ad0f');

-- ============================================================================
-- Tabla: api_connections
-- ============================================================================
INSERT INTO api_connections (id, name, base_url, auth_type, auth_config, api_key, is_active, created_at) VALUES ('56c084fb-6f4c-414f-aa38-04d646c00e91', 'OpenAI', 'https://api.openai.com/v1', 'bearer', '{}', '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', true, '2026-09-25 16:11:07.802127+00');
INSERT INTO api_connections (id, name, base_url, auth_type, auth_config, api_key, is_active, created_at) VALUES ('6de82853-a043-4518-b5bc-37c4c147f81f', 'Gemini AI', 'https://generativelanguage.googleapis.com', 'api_key', '{"header_name": "x-goog-api-key"}', 'AIzaSyDy4uoERAuMrLF-3ARA7_90SjiZJFaYc-g', true, '2026-09-25 16:11:07.802127+00');

-- ============================================================================
-- Tabla: firecrawl_connections
-- ============================================================================
INSERT INTO firecrawl_connections (id, name, target_url, credentials, is_active, created_at) VALUES ('f97fa1be-8083-4b13-ade8-8ed4e9dfa193', 'Griba', 'https://ruizcrm.griba.com.ar:64443/', '{"api_key": "fc-96ecf6ce6b304060a3ce30045a83426b", "password": "Admin2017FGHFG", "username": "gcontrastato"}', true, '2026-09-21 18:32:23.597995+00');

-- ============================================================================
-- Tabla: data_source_config
-- ============================================================================
INSERT INTO data_source_config (id, kpi_id, source_type, api_connection_id, firecrawl_connection_id, created_at) VALUES ('6814fd33-7e2b-44cf-b3b7-13944f35943d', '689281d2-8cdc-41d2-b6cf-cb8db518df97', 'external', NULL, 'f97fa1be-8083-4b13-ade8-8ed4e9dfa193', '2026-09-21 18:32:34.746313+00');

-- ============================================================================
-- Tabla: notifications
-- ============================================================================
INSERT INTO notifications (id, user_id, target_role, area_id, kpi_id, action, message, is_read, created_at) VALUES ('fd6b088c-4594-4878-a256-e8199547abcc', '1b724af6-4e80-42ab-bae5-8207ab8725d5', 'gerente', '5fe5c3f4-3916-4bfd-8667-c97f910b84f1', '29422146-8620-4804-9b56-4ca85f4dc444', 'create', 'cargó datos en "Cumplimiento y tiempo de entrega"', false, '2026-09-25 17:36:07.852874+00');
INSERT INTO notifications (id, user_id, target_role, area_id, kpi_id, action, message, is_read, created_at) VALUES ('c9dbea17-910a-48fe-a63c-950668296692', '1b724af6-4e80-42ab-bae5-8207ab8725d5', 'gerente', '5fe5c3f4-3916-4bfd-8667-c97f910b84f1', '311ccc80-8c46-4109-a7aa-b22f07245c6c', 'create', 'cargó datos en "Participación de mercado en Tucumán"', false, '2026-09-25 17:36:29.334474+00');

-- ============================================================================
-- Tabla: kpis (61 registros)
-- Nota: Ver archivo kpis_data.sql para los INSERT completos de esta tabla.
--       Se generaron dinámicamente y son demasiados para incluir inline.
-- ============================================================================

-- ============================================================================
-- INSTRUCCIONES:
-- Para tablas con muchos registros (kpis, kpi_data, kpi_breakdowns, custom_fields,
-- formulas, field_values, data_entries), los datos completos se generan
-- ejecutando las consultas de exportación en el proyecto original.
--
-- A continuación se incluyen los datos de las tablas pequeñas completas.
-- Para las tablas grandes, ver los archivos adicionales en esta carpeta.
-- ============================================================================

-- FIN DEL ARCHIVO PRINCIPAL
-- Los datos de tablas grandes (kpis, kpi_data, kpi_breakdowns, custom_fields,
-- formulas, field_values, data_entries) están en archivos separados
-- debido a su tamaño. Ver: kpis_inserts.sql, kpi_data_inserts.sql, etc.
